package edu.kh.poly.run;

import edu.kh.poly.ex1.model.service.PolyService;

public class PolyRun {

	public static void main(String[] args) {
		
		//new PolyService().ex1();
		
		//new PolyService().ex2();
		
		//new PolyService().ex4();

		new PolyService().ex5();
		
		
		
	}

}
