package edu.kh.collection.pack3.run;

import edu.kh.collection.pack3.model.service.MapService;

public class MapRun {
	public static void main(String[] args) {
		
		MapService service = new MapService();
		//service.ex1();
		//service.ex2();
		service.ex3();
		
	}
}
