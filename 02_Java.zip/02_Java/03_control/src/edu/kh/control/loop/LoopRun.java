package edu.kh.control.loop;

public class LoopRun {
	public static void main(String[] args) {
		ForExample forEx = new ForExample();
		
		//forEx.ex1();
		//forEx.ex2();
		//forEx.ex3();
		//forEx.ex4();
		//forEx.ex5();
		//forEx.ex6();
		//forEx.ex7();
		//forEx.ex8();
		//forEx.ex9();
		//forEx.ex10();
		//forEx.ex11();
		//forEx.ex12();
		//forEx.ex13();
		//forEx.ex14();		
		forEx.ex15();
	
	
	WhileExample whileEx = new WhileExample();
	//whileEx.ex1();
	//whileEx.ex2();
	
	
	
	
	
	
	}
}
