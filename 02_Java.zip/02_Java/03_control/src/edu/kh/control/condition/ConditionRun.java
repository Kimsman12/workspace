package edu.kh.control.condition;

public class ConditionRun {
	public static void main(String[] args) {
		ConditionExample coEx1 = new ConditionExample();
		
		//coEx1.ex1();
		//coEx1.ex2();
		//coEx1.ex3();
		//coEx1.ex4();
		
		//coEx1.ex5();
		//coEx1.ex6();
		//coEx1.ex7();
		coEx1.ex8();
		
		
	}
}
