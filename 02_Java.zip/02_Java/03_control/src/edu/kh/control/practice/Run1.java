package edu.kh.control.practice;

public class Run1 {
	public static void main(String[] args) {
		ConditionPractice coPr = new ConditionPractice();
	
		//coPr.practice1();
		//coPr.practice2();
		//coPr.practice3();
		//coPr.practice4();
		//coPr.practice5();
	
	
	
	
	
	
	
	
	
	}
	
}
