package edu.kh.variable.ex2;

import java.util.Scanner;

public class ScannerExample2 {
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("실수 1 입력 : ");
		double input1 = sc.nextDouble();
		
		System.out.println("실수 2 입력 : ");
		double input2 = sc.nextDouble();
		
		System.out.println("");
	}
}
