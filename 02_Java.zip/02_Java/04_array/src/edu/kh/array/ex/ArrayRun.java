package edu.kh.array.ex;

public class ArrayRun {
	public static void main(String[] args) {
		
		ArrayExample arrayEx1 = new ArrayExample();
		
		//arrayEx1.ex1();
		//arrayEx1.ex2();
		//arrayEx1.ex3();
		//arrayEx1.ex4();
		//arrayEx1.ex5();
		//arrayEx1.ex6();
		//arrayEx1.ex7();
		//arrayEx1.ex9();
		
		ArrayExample2 arrayEx2 = new ArrayExample2();
		
		//arrayEx2.shallowCopy();
		//arrayEx2.deepCopy();
		arrayEx2.createLottoNumber();
		
	}

}

