package edu.kh.array.practice.run;

import edu.kh.array.practice.service.PracticeService;

public class PracticeRun {
	public static void main(String[] args) {
		
		PracticeService prSer = new PracticeService();
		
		//prSer.practice1();
		//prSer.practice2();
		//prSer.practice3();
		//prSer.practice4();
		//prSer.practice5();
		//prSer.practice6();
		//prSer.practice7();
		//prSer.practice8();
		//prSer.practice9();
		//prSer.practice10();
		//prSer.practice11();
		//prSer.practice12();
		//prSer.practice13();
		//prSer.practice14();
	}
}
