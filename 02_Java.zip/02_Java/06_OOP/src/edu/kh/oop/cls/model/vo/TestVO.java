package edu.kh.oop.cls.model.vo;

class TestVO {
	// 접근제한자(default)  : 같은 패키지 내에서만 import가 가능함
	// - 아무것도 안쓰면 default

}
