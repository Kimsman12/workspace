package edu.kh.exeption.model.service;

public class UserException extends Exception{

	public UserException() {}
	
	public UserException(String msg) {
		super(msg);
	}

	
	
	
}
