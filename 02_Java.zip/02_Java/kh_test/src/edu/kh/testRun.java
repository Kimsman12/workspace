package edu.kh;

public class testRun {

	public testRun() {
		// TODO Auto-generated constructor stub
	}

}
