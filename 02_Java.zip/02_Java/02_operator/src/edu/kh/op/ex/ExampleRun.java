package edu.kh.op.ex;

public class ExampleRun {// 코드 실행용 클래스
	
	// 메인메서드 필수 작성
	public static void main(String[] args) {
		
		// OpExample 생성
		// -> OpExample 이라는 클래스(설계도) 를 이용해서
		// 객체를 생성하는데, 그 객체 이름이 ex 다.
		OpExample opEx = new OpExample();
		// 같은 패키지 안에 있는 클래스는
		// import를 하지 않아도 불러다 쓸 수 있다.
		
		//opEx.ex1(); // opEx가 가지고 있는 ex1() 메서드를 실행
		//opEx.ex2();
		//opEx.ex3();
		//opEx.ex4();
	}
}

