package edu.kh.op.practice;

public class PracticeRun3 {
	public static void main(String[] args) {
		OperatorPractice3 opOp3 = new OperatorPractice3();
		
		//opOp3.practice3();
		
		opOp3.practice4();
		
		//opOp3.practice5();
	}
}
