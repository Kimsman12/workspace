package edu.kh.op.practice;

public class PracticeRun2 {
	public static void main(String[] args) {
		
		OperatorPractice2 opOp2 = new OperatorPractice2();
		opOp2.practice1();
		
	}
}
