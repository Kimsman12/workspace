package edu.kh.op.practice;

public class PracticeRun {
	public static void main(String[] args) {
		OperatorPractice opOp2 = new OperatorPractice();
		
		//opOp.practice1();
		
		//opOp.practice2();
		
		//opOp.practice3();

		//OperatorPractice2 opOp2 = new OperatorPractice2();
		
		//opOp2.practice1();

	
	
	
	
	
	
	}
}
